<template>
	<div class="navbar">
		<ul class="container-xl">
			<li><a href="#">Discord</a></li>
		</ul>
	</div>
</template>

<script lang="ts">
import Vue from 'vue';

export default Vue.extend({
	name: 'Navbar',
	props: {
		items: Array,
	},
});
</script>

<style lang="scss">
@import '../styles/colors.scss';
.navbar {
	width: 100%;
	background: $dark-blue;
	ul {
		list-style-type: none;
		li {
			margin: 0px;
			a {
				text-decoration: none;
				color: white;
			}
		}
	}
}
</style>
