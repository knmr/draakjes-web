<template>
	<div id="app" class="container">
		<Navbar />
		<Home />
		<Background />
	</div>
</template>

<script lang="ts">
import Vue from 'vue';
import Home from './components/Home.vue';
import Navbar from './components/Navbar.vue';
import Background from './components/Background.vue';

export default Vue.extend({
	name: 'App',
	components: {
		Home,
		Navbar,
		Background,
	},
});
</script>

<style lang="scss">
#app {
	font-family: 'Quicksand', sans-serif, Verdana, Geneva, sans-serif;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	font-weight: 300;
	font-size: 20px;
	// line-height: 2.5em;
}
</style>
